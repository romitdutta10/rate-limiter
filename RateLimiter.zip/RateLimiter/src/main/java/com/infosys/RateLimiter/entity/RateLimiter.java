package com.infosys.RateLimiter.entity;

import java.time.ZonedDateTime;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class RateLimiter {
	
	@Id
	private Integer id;
	private Integer threshold;
	private ZonedDateTime startTime;
	private Integer requests;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getLimit() {
		return threshold;
	}
	public void setLimit(Integer limit) {
		this.threshold = limit;
	}
	public ZonedDateTime getStartTime() {
		return startTime;
	}
	public void setStartTime(ZonedDateTime startTime) {
		this.startTime = startTime;
	}
	public Integer getRequests() {
		return requests;
	}
	public void setRequests(Integer requests) {
		this.requests = requests;
	}
	
	

}
