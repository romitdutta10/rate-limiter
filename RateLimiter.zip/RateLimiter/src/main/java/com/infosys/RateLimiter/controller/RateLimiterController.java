package com.infosys.RateLimiter.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infosys.RateLimiter.service.RateLimiterService;

@RestController
public class RateLimiterController {
	
	@Autowired
	private RateLimiterService rateLimiterService;
	
	@GetMapping("/get")
	private String getDetails() {
		return rateLimiterService.getResponse();
	}
	
	@PutMapping("/set-limit/{limit}")
	private void setThreshold(@PathVariable int limit) {
		rateLimiterService.setThreshold(limit);
	}

}
