package com.infosys.RateLimiter.service;

import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infosys.RateLimiter.entity.RateLimiter;
import com.infosys.RateLimiter.repository.RateLimiterRepository;

@Service
public class RateLimiterService {
	
	@Autowired
	private RateLimiterRepository repo;
	
	@Transactional
	public String getResponse() {
		
		RateLimiter rateLimiter = repo.findById(1).orElse(new RateLimiter());
		
		ZonedDateTime startTime = rateLimiter.getStartTime();
		ZonedDateTime currentTime = ZonedDateTime.now();
		
		if( startTime == null || ChronoUnit.SECONDS.between(startTime, currentTime) > 1) {
			rateLimiter.setStartTime(currentTime);
			repo.save(rateLimiter);
			return "Request sent successfully";
		} else {
			int request = rateLimiter.getRequests()!= null ? rateLimiter.getRequests() : 0;
			int threshold = rateLimiter.getLimit()!=null ? rateLimiter.getLimit() : 100;
			
			if(request >= threshold) {
				return "Request limit exceeded. Request Failed";
			} else {
				
				rateLimiter.setRequests(request + 1);
				repo.save(rateLimiter);
				return "Request sent successfully";
				
			}
		}
		
	}
	
	@Transactional
	public void setThreshold(int limit) {
		RateLimiter rateLimiter = repo.findById(1).orElse(new RateLimiter());
		rateLimiter.setId(1);
		rateLimiter.setLimit(limit);
		repo.save(rateLimiter);
	}
	
	

}
