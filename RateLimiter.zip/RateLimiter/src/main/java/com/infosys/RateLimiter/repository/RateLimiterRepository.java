package com.infosys.RateLimiter.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.infosys.RateLimiter.entity.RateLimiter;

@Repository
public interface RateLimiterRepository extends JpaRepository<RateLimiter, Integer> {

}
