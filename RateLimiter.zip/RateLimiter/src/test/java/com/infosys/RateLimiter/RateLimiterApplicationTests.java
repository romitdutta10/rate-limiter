package com.infosys.RateLimiter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RateLimiterApplicationTests {

	@Test
	void contextLoads() {
	}

}
